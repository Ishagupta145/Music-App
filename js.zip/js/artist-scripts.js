// Sample Chart.js Data Visualization for Track Plays

// Check if the canvas element exists
document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById('playsChart').getContext('2d');
    
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul'],
        datasets: [{
          label: 'Plays',
          data: [5000, 10000, 7500, 12000, 9000, 15000, 13000],
          backgroundColor: 'rgba(233, 30, 99, 0.5)',
          borderColor: '#e91e63',
          borderWidth: 2,
          fill: true
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: true
          }
        }
      }
    });
  });
  